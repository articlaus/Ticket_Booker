package edu.mum.service.impl;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.mum.dao.PassengerDao;
import edu.mum.domain.Passenger;
import edu.mum.service.PassengerService;
@Component
public class PassengerServiceImpl implements PassengerService{
	
	@Autowired
	private PassengerDao passengerDao;

@Override
	public List<Passenger> findAll() {
		return (List<Passenger>)passengerDao.findAll();
	}

	


	@Override
	public void save(Passenger passenger) {
		  		
				passengerDao.save(passenger);
		
	}


	@Override
	public Passenger findOne(Long id) {
		// TODO Auto-generated method stub
		Passenger passenger= passengerDao.findOne(id);
		return passenger;
	}




	@Override
	public Passenger update(Passenger passenger) {
		// TODO Auto-generated method stub
		return passengerDao.update(passenger);
	}

}
