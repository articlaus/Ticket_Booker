package edu.mum.service;

import java.util.List;
import edu.mum.domain.Passenger;

public interface PassengerService {
	public void save(Passenger passenger); 
	public Passenger update(Passenger passenger);

public List<Passenger> findAll();
	public Passenger findOne(Long id);
}
