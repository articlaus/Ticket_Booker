package edu.mum.service;

import java.util.List;

import edu.mum.domain.Ticket;

public interface TicketService {
	public void save(Ticket ticket); 
	public Ticket update(Ticket ticket);

public List<Ticket> findAll();
	public Ticket findOne(Long id);
}
