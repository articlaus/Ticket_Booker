package edu.mum.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.mum.dao.PassengerDao;
import edu.mum.dao.TicketDao;
import edu.mum.domain.Passenger;
import edu.mum.domain.Ticket;
import edu.mum.service.TicketService;

@Component
public class TicketServiceImpl implements TicketService{
	@Autowired
	private TicketDao ticketDao;

@Override
	public List<Ticket> findAll() {
		return (List<Ticket>)ticketDao.findAll();
	}

	


	@Override
	public void save(Ticket ticket) {
		  		
				ticketDao.save(ticket);
		
	}


	@Override
	public Ticket findOne(Long id) {
		// TODO Auto-generated method stub
		Ticket ticket= ticketDao.findOne(id);
		return ticket;
	}




	@Override
	public Ticket update(Ticket ticket) {
		// TODO Auto-generated method stub
		return ticketDao.update(ticket);
	}

}
