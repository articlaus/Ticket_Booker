package edu.mum.domain;


import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "ticket")
public class Ticket {

	@Id
	@GeneratedValue
	@Column(name = "ticket_id")
	long ticket_id;
	@Column(name = "issueDate")
	@Temporal(TemporalType.DATE)
    Date issuedDate;
	@Column(name = "seatNumber")
	String seatNumber;
	@OneToOne(cascade= CascadeType.ALL)
	Passenger passenger;
	

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	public Ticket() {

	}

	public long getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(long ticket_id) {
		this.ticket_id = ticket_id;
	}

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void SetIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public 	String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

}
