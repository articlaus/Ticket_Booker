package edu.mum.dao;

import edu.mum.domain.Ticket;

public interface TicketDao extends GenericDao<Ticket> {

}
