package edu.mum.dao;

import edu.mum.domain.Passenger;

public interface PassengerDao extends GenericDao<Passenger> {

}
