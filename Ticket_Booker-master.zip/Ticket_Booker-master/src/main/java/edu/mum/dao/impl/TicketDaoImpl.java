package edu.mum.dao.impl;

import org.springframework.stereotype.Repository;

import edu.mum.dao.TicketDao;
import edu.mum.domain.Ticket;

@Repository
public class TicketDaoImpl extends GenericDaoImpl<Ticket> implements TicketDao {
	public TicketDaoImpl() {
		super.setDaoType(Ticket.class );
		}

	

}
