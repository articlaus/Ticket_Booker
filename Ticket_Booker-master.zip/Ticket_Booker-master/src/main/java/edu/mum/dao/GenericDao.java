package edu.mum.dao;

import java.util.List;

public interface GenericDao<T> {
	void save(T t);


    T findOne(Long id);

    T update(T t);   
    
    List<T> findAll();

	void delete(Long id);

}
