package edu.mum;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.mum.domain.Passenger;
import edu.mum.domain.Ticket;
import edu.mum.service.PassengerService;
import edu.mum.service.TicketService;

@Component
public class TestData {

	@Autowired
	PassengerService passengerService;

	@Autowired
	TicketService ticketService;
	List<Ticket> tickets = new ArrayList<Ticket>();

	public void setData() {
		// TODO Auto-generated method stub
		Ticket ticket1 = new Ticket();
		Passenger passenger = new Passenger();
		System.out.println("est");
		ticket1.setSeatNumber("12A");

		passenger.setDob("1988/12/12");
		passenger.setAddress("380 Euclid Avenue Apt 1");
		passenger.setEmail("yobiel@gmail.com");
		passenger.setFirstName("Yobiel");
		passenger.setLastName("Abraham");
		passenger.setGender("Male");

		Ticket ticket2 = new Ticket();
		ticket2.setSeatNumber("22E");

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Date issuedDate1 = null;
		Date issuedDate2 = null;

		try {
			issuedDate1 = formatter.parse("2018-12-17 08:34:55.705");
			issuedDate2 = formatter.parse("2018-12-26 06:14:55.705");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ticket1.SetIssuedDate(issuedDate1);
		ticket2.SetIssuedDate(issuedDate2);
		ticketService.save(ticket1);
		ticketService.save(ticket2);
		tickets.add(ticket1);
		tickets.add(ticket2);
		passengerService.save(passenger);

	}
}
