package edu.mum.amqp;

import edu.mum.domain.Flight;

public class FlightListener {
	
	public void listen(Flight flight) {		
		System.out.println(
				"---------- AMQP direct consumer (on directQueue) for Item: " + flight.getFromAirport()+
				flight.getToAirport()+flight.getTotalSeat()+ flight.getDepartureTime()+ flight.getArrivalTime()+
				flight.getTotalSeat()+ flight.getId()
		);
	}
}
